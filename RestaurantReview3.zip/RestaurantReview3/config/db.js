// Configuration setting with mongoDB connection URI
module.exports = {
    URI: "mongodb+srv://aryanpatel14:rAXzRaHYONStDT6q@cluster0.cfyc4.mongodb.net/reviews",
};
  